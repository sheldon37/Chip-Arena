import * as T from 'three';
import type {CharacterRig} from './character-rig.js';
import type {PlayerView} from '../shared/simulation.js';
const sat=(x:number)=>T.MathUtils.clamp(x,0,1),ease=(x:number)=>{x=sat(x);return x*x*(3-2*x);};
export function emperorGuard(r:CharacterRig,time:number){
 r.body.position.y=-.045+Math.sin(time*5)*.006;r.body.rotation.set(.04,-.3,0);r.pelvis.rotation.set(0,-.12,0);r.chest.rotation.set(0,.28,0);r.head.rotation.set(0,.12,0);
 r.leftArm.rotation.set(-.8,-.15,.08);r.leftElbow.rotation.set(-1.4,0,0);r.rightArm.rotation.set(-.55,.12,-.18);r.rightElbow.rotation.set(-1.95,0,0);
 r.leftLeg.rotation.set(-.23,0,.14);r.rightLeg.rotation.set(.2,0,-.18);r.leftKnee.rotation.x=.3;r.rightKnee.rotation.x=.2;r.leftFoot.rotation.x=-.1;r.rightFoot.rotation.x=-.25;
}
/** Absolute authoritative hit times preserve the same launch and spin for all observers. */
export function animateJuggle(r:CharacterRig,p:PlayerView,time:number){
 const j=p.juggle!;const age=Math.max(0,time-j.lastHit),kick=Math.exp(-age*7),spin=j.spinUntil>time;
 r.body.position.y=.03;r.body.rotation.set(-.7-kick*.55,spin?(j.spinUntil-time)*9:Math.sin((time-j.at)*4)*.18,Math.sin(time*8)*.10);
 r.spine.rotation.set(.24,0,0);r.chest.rotation.set(.22,0,.13*kick);r.head.rotation.set(-.32,0,.08);
 r.leftArm.rotation.set(-.45,0,.65+.2*kick);r.rightArm.rotation.set(.25,0,-.75);r.leftElbow.rotation.x=-.75;r.rightElbow.rotation.x=-.4;
 r.leftLeg.rotation.set(-.85-.25*kick,0,.22);r.rightLeg.rotation.set(-.4,0,-.25);r.leftKnee.rotation.x=1.3;r.rightKnee.rotation.x=.85+.2*Math.sin(time*9);r.leftFoot.rotation.x=r.rightFoot.rotation.x=-.2;
}
export function animateEmperor(r:CharacterRig,p:PlayerView,time:number){
 const speed=Math.hypot(p.vel.x,p.vel.z),leg=[r.leftLeg.rotation.clone(),r.rightLeg.rotation.clone(),r.leftKnee.rotation.clone(),r.rightKnee.rotation.clone()];emperorGuard(r,time);
 if(speed>1&&p.grounded&&!p.waveTime){[r.leftLeg,r.rightLeg,r.leftKnee,r.rightKnee].forEach((n,i)=>n.rotation.copy(leg[i]));}
 r.weapon.rotation.set(0,0,0);r.offWeapon.rotation.set(0,0,0);r.weapon.scale.setScalar(1);r.offWeapon.scale.setScalar(1);r.weapon.visible=r.offWeapon.visible=true;
 if(p.blockTime>0){r.leftArm.rotation.set(-1.3,0,.08);r.rightArm.rotation.set(-1.2,0,-.08);r.leftElbow.rotation.x=r.rightElbow.rotation.x=-1.55;return;}
 const a=p.emperor;if(speed>1&&p.grounded&&!p.waveTime&&!a?.action){const gait=Math.sin(r.stride)*Math.min(1,speed/6.8);r.rightArm.rotation.x+=gait*.4;r.leftArm.rotation.x-=gait*.4;}if(!a?.action||time>a.until+.08)return;const age=Math.max(0,time-a.at),duration=a.until-a.at;
 if(a.action==='wave'){
  const u=sat(age/.18),dip=Math.sin(u*Math.PI);r.body.position.y=-.08-.28*dip;r.body.position.z=.12*dip;r.body.rotation.x=.28*dip;r.leftLeg.rotation.x=-.75*dip;r.leftKnee.rotation.x=1.45*dip;r.rightLeg.rotation.x=.35*dip;r.rightKnee.rotation.x=.75*dip;r.leftFoot.rotation.x=-.65*dip;r.rightFoot.rotation.x=-.6*dip;r.rightArm.rotation.x=-.4;r.leftArm.rotation.x=-1;
 }else if(a.action==='electric'){
  // The planted crouch-dash unwinds into a bent-elbow hook at the authority's hit frame.
  const u=sat(age/duration),coil=ease(u/.115)*(1-ease((u-.115)/.135)),drive=ease((u-.115)/.135),hold=1-ease((u-.48)/.52),power=drive*hold;
  r.body.position.y=-.23*coil+.025*power;r.body.position.z=.09*coil+.17*power;
  r.body.rotation.set(.24*coil-.09*power,-.3-.42*coil+.5*power,-.06*power);r.pelvis.rotation.y=-.12-.2*coil+.25*power;r.chest.rotation.y=.28-.35*coil+.18*power;r.head.rotation.set(-.08*power,.12-.4*power,0);
  r.rightArm.rotation.set(-.55+.45*coil-1.25*power,.12+.32*power,-.18-.22*power);r.rightElbow.rotation.x=-1.95+.85*coil+.73*power;r.rightHand.rotation.y=-.4*power;
  r.leftArm.rotation.set(-.8+.35*power,-.15,.08+.16*power);r.leftElbow.rotation.x=-1.4-.35*power;
  r.leftLeg.rotation.set(-.23-.4*coil-.12*power,0,.14);r.leftKnee.rotation.x=.3+.7*coil+.12*power;
  r.rightLeg.rotation.set(.2-.2*coil+.18*power,0,-.18);r.rightKnee.rotation.x=.2+.75*coil;r.leftFoot.rotation.x=-.1;r.rightFoot.rotation.x=-.25-.15*power;

 }else{
  const rate=p.attackRate||1,gap=.17/rate,index=Math.min(a.total-1,Math.max(0,Math.floor((age-.075/rate+.05/rate)/gap))),phase=(age-.075/rate-index*gap)*rate,u=phase<0?ease((phase+.08)/.08):1-ease((phase-.025)/.115),left=index%2===0,sign=left?1:-1,arm=left?r.leftArm:r.rightArm,elbow=left?r.leftElbow:r.rightElbow;
  r.body.rotation.y=-.3+.42*sign*u;r.chest.rotation.y=.28+.25*sign*u;r.head.rotation.y=.12-.28*sign*u;r.body.position.z=.13*u;arm.rotation.set(-1.48,-.08*sign,.08*sign);elbow.rotation.x=-1.4*(1-u)-.03;r.rightKnee.rotation.x+=.12*u;
 }
}
