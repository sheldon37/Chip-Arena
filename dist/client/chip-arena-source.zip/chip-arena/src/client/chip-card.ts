import {Chip,RARITIES} from '../shared/content.js';
export const rarityStyle=(c:Chip)=>`--rarity:${RARITIES[c.rarity].color}`;
export function chipCard(c:Chip,copies=0){
 const tier=RARITIES[c.rarity],particles=c.rarity==='mythic'?14:c.rarity==='legendary'?6:0;
 return `<button class="chip circuit-chip rarity-${c.rarity}" style="${rarityStyle(c)}" data-chip="${c.id}" aria-label="${c.name}, ${tier.name}. ${c.description}"><span class="chip-particles" aria-hidden="true">${Array.from({length:particles},(_,n)=>`<i style="--n:${n};--x:${(n*37+11)%100}%;--delay:${-n*.31}s"></i>`).join('')}</span><span class="circuit-header"><span class="chip-icon" aria-hidden="true">${c.icon}</span><span><span class="rarity-label">${tier.name}</span><strong>${c.name}</strong></span></span><p>${c.description}</p><span class="chip-footer"><span>${c.tags[0]==='projectile'?'GUNS + MAGIC':c.tags[0]==='all'?'ALL WEAPONS':c.tags[0].toUpperCase()}</span><span>${copies?`×${copies} → ×${copies+1}`:'INSTALL'} / ${c.max}</span></span><span class="chip-notch" aria-hidden="true"></span></button>`;
}
