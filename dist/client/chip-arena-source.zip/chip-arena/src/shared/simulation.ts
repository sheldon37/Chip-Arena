import {NETWORK} from './network-config.js';
import {prepareMotion,finishMotion} from './movement.js';
import RAPIER from '@dimforge/rapier3d-compat';
import {CONFIG as C,MATERIALS,Material,Vec,v,add,sub,mul,dot,len,norm,clamp,forward,idleInput,Input,ClassId,SpecId,Difficulty} from './config.js';
import {blockCooldown,blockDuration} from './blocking.js';
import {WEAPONS,CLASS_INFO,CHIPS,statsFor,offerChips,Stats,magazineCapacity} from './content.js';
import {steerVelocity,ballisticStep,ballisticPitch} from './projectiles.js';
import {cameraPosition,weaponMuzzle} from './view.js';
import {DotState,ElementId,refreshDot,advanceDots,attackElements} from './elements.js';
import {arenaBlocks,ArenaBlock} from './arena.js';
import {ImpactLedger,impactDamage,pointVelocity,closingSpeed} from './impact.js';
export {RAPIER};
let initializing:Promise<void>|undefined;
export const initPhysics=()=>initializing??=(RAPIER.init());
export type Phase='lobby'|'specialization'|'countdown'|'fight'|'result'|'draft'|'match';
export interface Player {
 id:string;name:string;color:string;class:ClassId;spec:SpecId;ready:boolean;connected:boolean;disconnectedAt:number|null;bot:Difficulty|null;
 body:RAPIER.RigidBody;collider:RAPIER.Collider;input:Input;inputAt:number;ack:number;
 hp:number;mana:number;ammo:number;stamina:number;staminaAt:number;guarding:boolean;
 blockTime:number;blockCd:number;blockHeld:boolean;blockProcUsed:boolean;lastBlock:number;
 cooldown:number;secondaryCd:number;dashCd:number;dashTime:number;reloadTime:number;parryTime:number;
 ext:Vec;move:Vec;grounded:boolean;chips:Record<string,number>;stats:Stats;score:number;roundWins:number;selected:boolean;offers:string[];
 swing:{at:number;until:number;id:string;hit:Set<string>;yaw:number;remaining:number;damageScale:number}|null;burst:number;burstAt:number;
 burns:Map<string,DotState>;poisons:Map<string,DotState>;hits:number;lastSource:string|null;sourceAt:number;
 lastDamage:number;lastAttack:number;lastSecondary:number;botAim:Vec;botThink:number;botBlocked:number;previousPos:Vec;
}
export interface Prop {id:string;body:RAPIER.RigidBody;collider:RAPIER.Collider;size:Vec;material:Material;hp:number;maxHp:number;mass:number;dynamic:boolean;support?:string[];group:string;source:string|null;sourceAt:number;born:number;fragment:boolean;}
export interface Projectile {reflections?:number;burnDps?:number;poisonDps?:number;demolition?:number;elements?:ElementId[];id:string;pos:Vec;vel:Vec;owner:string;spec:SpecId;damage:number;impulse:number;life:number;radius:number;direct:boolean;attackId:string;bounces:number;pierces:number;hit:Set<string>;effectsUsed:boolean;homing:number;distanceLeft:number;gravity:number;}
export interface GameEvent{time:number;spec?:SpecId;material?:Material;id:number;type:string;pos:Vec;from?:Vec;target?:string;source?:string|null;amount?:number;color?:number;radius?:number;message?:string;}
export interface ImpactDebug{mass:number;speed:number;energy:number;damage:number;source:string;object:string;time:number;}
export interface Options{inputHoldSeconds?:number;bothDraft?:boolean;sandbox?:boolean;wins?:number;roundsPerSet?:number;selectionSeconds?:number;countdown?:number;resultSeconds?:number;seed?:number;}
export interface PlayerView {move?:Vec;external?:Vec;dashTime?:number;swinging?:boolean;statuses:{element:ElementId;dps:number;remaining:number}[];id:string;name:string;color:string;class:ClassId;spec:SpecId;pos:Vec;vel:Vec;yaw:number;pitch:number;hp:number;maxHp:number;mana:number;maxMana:number;ammo:number;maxAmmo:number;stamina:number;maxStamina:number;blockTime:number;blockCd:number;blockCooldown:number;blockDuration:number;lastBlock:number;guarding:boolean;dashCd:number;secondaryCd:number;cooldown:number;reloadTime:number;score:number;roundWins:number;chips:Record<string,number>;ready:boolean;selected:boolean;offers:string[];connected:boolean;bot:Difficulty|null;ack:number;grounded:boolean;lastAttack:number;lastSecondary:number;reach:number;windup:number;}
export interface PropView {id:string;pos:Vec;rot:{x:number;y:number;z:number;w:number};size:Vec;material:Material;hp:number;maxHp:number;mass:number;dynamic:boolean;support?:string[];fragment:boolean;vel:Vec;}
export interface Snapshot {generation?:number;time:number;tick:number;phase:Phase;remaining:number;round:number;setNumber:number;setWinner:string|null;winner:string|null;result:string;players:PlayerView[];props:PropView[];projectiles:{owner:string;reflections:number;elements:ElementId[];id:string;pos:Vec;vel:Vec;spec:SpecId;radius:number}[];events:GameEvent[];impact:ImpactDebug|null;metrics:{bodies:number;projectiles:number;tickMs:number};options:Options;}
const copy=(a:Vec):Vec=>v(a.x,a.y,a.z);
function rotate(q:{x:number;y:number;z:number;w:number},p:Vec):Vec{const tx=2*(q.y*p.z-q.z*p.y),ty=2*(q.z*p.x-q.x*p.z),tz=2*(q.x*p.y-q.y*p.x);return v(p.x+q.w*tx+q.y*tz-q.z*ty,p.y+q.w*ty+q.z*tx-q.x*tz,p.z+q.w*tz+q.x*ty-q.y*tx);}
export function sanitizeInput(raw:any):Input|null {if(!raw||!['seq','x','z','yaw','pitch'].every(k=>typeof raw[k]==='number'&&Number.isFinite(raw[k])))return null;if(!Number.isSafeInteger(raw.seq)||raw.seq<0)return null;return {camera:raw.camera==='first'?'first':'third',seq:raw.seq,x:clamp(raw.x,-1,1),z:clamp(raw.z,-1,1),yaw:raw.yaw%(Math.PI*2),pitch:clamp(raw.pitch,-1.35,1.35),attack:raw.attack===true,block:raw.block===true,secondary:raw.secondary===true,jump:raw.jump===true,dash:raw.dash===true,reload:raw.reload===true};}
export class Simulation {
 generation=0;private inputQueues=new Map<string,{queue:Input[];received:number;window:number;count:number}>();
 world:RAPIER.World;players=new Map<string,Player>();props=new Map<string,Prop>();projectiles=new Map<string,Projectile>();
 colliderOwners=new Map<number,string>();time=0;tick=0;phase:Phase='lobby';phaseEnd=0;fightStart=0;round=1;setNumber=1;setWinner:string|null=null;winner:string|null=null;result='';
 events:GameEvent[]=[];impact:ImpactDebug|null=null;ledger=new ImpactLedger();options:Options;tickMs=0;private serial=0;private seed:number;private procAttacks=new Set<string>();
 constructor(options:Options={}){this.options={wins:C.wins,roundsPerSet:C.roundsPerSet,bothDraft:false,sandbox:false,selectionSeconds:C.selectionSeconds,countdown:C.countdown,resultSeconds:C.resultSeconds,...options};this.seed=options.seed||23819;this.world=new RAPIER.World(v(0,C.gravity,0));this.world.timestep=1/C.simulationHz;this.world.maxCcdSubsteps=4;this.resetArena();}
 random(){this.seed=(Math.imul(this.seed,1664525)+1013904223)>>>0;return this.seed/4294967296;}
 uid(prefix:string){return `${prefix}-${++this.serial}`;}
 emit(type:string,pos:Vec,extra:Partial<GameEvent>={}){this.events.push({id:++this.serial,time:this.time,type,pos:copy(pos),...extra});if(this.events.length>C.maxEvents)this.events.shift();}
 addPlayer(id:string,name='Pilot',cls:ClassId='ranged',bot:Difficulty|null=null,color='#70e1d0'){
 if(this.players.size>=2||this.players.has(id))return null;
 const body=this.world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(this.players.size?0:0,2,this.players.size?(this.options.sandbox?-1:8):-8).lockRotations().setCcdEnabled(true).setLinearDamping(0).setCanSleep(false));
 const collider=this.world.createCollider(RAPIER.ColliderDesc.capsule(C.playerHalfHeight,C.playerRadius).setMass(C.playerMass).setFriction(0).setRestitution(0),body);
 const p:Player={id,name:name.replace(/[<>]/g,'').slice(0,20)||'Pilot',color:/^#[0-9a-f]{6}$/i.test(color)?color:'#70e1d0',class:cls,spec:CLASS_INFO[cls].default,ready:!!bot,connected:true,disconnectedAt:null,bot,body,collider,input:idleInput(),inputAt:this.time,ack:0,hp:100,mana:100,ammo:WEAPONS[CLASS_INFO[cls].default].ammo,stamina:100,staminaAt:-10,guarding:false,blockTime:0,blockCd:0,blockHeld:false,blockProcUsed:false,lastBlock:-10,cooldown:0,secondaryCd:0,dashCd:0,dashTime:0,reloadTime:0,parryTime:0,ext:v(),move:v(),grounded:false,chips:{},stats:statsFor({}),score:0,roundWins:0,selected:false,offers:[],swing:null,burst:0,burstAt:0,burns:new Map(),poisons:new Map(),hits:0,lastSource:null,sourceAt:0,lastDamage:0,lastAttack:-10,lastSecondary:-10,botAim:v(),botThink:0,botBlocked:0,previousPos:v()};
 this.players.set(id,p);this.colliderOwners.set(collider.handle,id);return p;
 }
 setInput(id:string,raw:any){const p=this.players.get(id),input=sanitizeInput(raw);if(!p||!input||input.seq<=p.input.seq)return false;p.input=input;p.inputAt=this.time;return true;}
 queueInputs(id:string,raw:unknown,epoch:string){
 const p=this.players.get(id);if(!p||!p.connected||this.phase!=='fight'||epoch!==`${this.setNumber}:${this.round}:${this.generation}`||!Array.isArray(raw)||!raw.length||raw.length>NETWORK.maxInputBatch)return false;
 const inputs=raw.map(sanitizeInput);if(inputs.some(i=>!i)||inputs.some((i,n)=>n>0&&i!.seq<=inputs[n-1]!.seq))return false;
 let q=this.inputQueues.get(id);if(!q){q={queue:[],received:p.input.seq,window:this.time,count:0};this.inputQueues.set(id,q);}
 const fresh=(inputs as Input[]).filter(i=>i.seq>q!.received);if(!fresh.length)return true;
 if(this.time-q.window>=1){q.window=this.time;q.count=0;}if(q.count+fresh.length>C.maxInputRate||q.queue.length+fresh.length>NETWORK.inputQueueLimit)return false;
 q.count+=fresh.length;q.queue.push(...fresh);q.received=fresh.at(-1)!.seq;p.inputAt=this.time;return true;
 }
 setClass(id:string,cls:ClassId){const p=this.players.get(id);if(!p||this.phase!=='lobby'||!Object.hasOwn(CLASS_INFO,cls))return false;p.class=cls;p.spec=CLASS_INFO[cls].default;p.ready=false;return true;}
 setReady(id:string,ready:boolean){if(this.phase!=='lobby')return false;const p=this.players.get(id);if(!p)return false;p.ready=ready;if(this.players.size===2&&[...this.players.values()].every(p=>p.ready))this.start();return true;}
 start(){if(this.players.size!==2)return;this.winner=null;this.setWinner=null;this.setNumber=1;this.round=1;for(const p of this.players.values()){p.chips={};p.score=0;p.roundWins=0;p.offers=[];p.selected=false;}this.resetRound();this.phase='specialization';this.phaseEnd=this.time+this.options.selectionSeconds!;}
 selectSpec(id:string,spec:SpecId){const p=this.players.get(id);if(!p||this.phase!=='specialization'||p.selected||!Object.hasOwn(WEAPONS,spec)||WEAPONS[spec].class!==p.class)return false;p.spec=spec;p.selected=true;p.ammo=magazineCapacity(spec,p.stats);if([...this.players.values()].every(p=>p.selected))this.countdown();return true;}
 selectChip(id:string,chip:string){const p=this.players.get(id);if(!p||this.phase!=='draft'||p.selected||!p.offers.includes(chip))return false;p.chips[chip]=(p.chips[chip]||0)+1;p.selected=true;p.offers=[];if([...this.players.values()].every(p=>p.selected))this.beginNextSet();return true;}
 countdown(){this.winner=null;this.setWinner=null;this.phase='countdown';this.phaseEnd=this.time+this.options.countdown!;for(const p of this.players.values())p.ammo=magazineCapacity(p.spec,p.stats);}
 rematch(){if(this.phase!=='match')return false;this.start();return true;}
 returnLobby(){this.phase='lobby';this.winner=null;this.setWinner=null;this.setNumber=1;this.round=1;for(const [pid,p] of this.players)if(!p.connected){this.colliderOwners.delete(p.collider.handle);this.world.removeRigidBody(p.body);this.players.delete(pid);}for(const p of this.players.values()){p.ready=!!p.bot;p.chips={};p.score=0;p.roundWins=0;p.offers=[];}this.resetRound();}
 disconnect(id:string){this.inputQueues.delete(id);const p=this.players.get(id);if(p){p.connected=false;p.disconnectedAt=this.time;p.input=idleInput();}}
 resetRound(){this.generation++;this.inputQueues.clear();this.resetArena();let i=0;for(const p of this.players.values()){p.stats=statsFor(p.chips);p.hp=p.stats.hp;p.mana=p.stats.maxMana;p.ammo=magazineCapacity(p.spec,p.stats);p.stamina=p.stats.maxStamina;p.staminaAt=-10;p.guarding=false;p.blockTime=p.blockCd=0;p.blockHeld=p.blockProcUsed=false;p.lastBlock=-10;p.cooldown=p.secondaryCd=p.dashCd=p.dashTime=p.reloadTime=p.parryTime=0;p.ext=v();p.move=v();p.burns.clear();p.poisons.clear();p.hits=0;p.swing=null;p.burst=0;p.lastSource=null;p.lastAttack=-10;p.input=idleInput();p.input.yaw=i?Math.PI:0;p.body.setTranslation(v(0,1.1,i?(this.options.sandbox?-1:8):-8),true);p.body.setLinvel(v(),true);p.body.setAngvel(v(),true);p.grounded=false;p.ack=p.input.seq;i++;}this.events=[];this.impact=null;this.ledger.clear();this.procAttacks.clear();}
 resetArena(){for(const prop of this.props.values()){this.colliderOwners.delete(prop.collider.handle);this.world.removeRigidBody(prop.body);}this.props.clear();this.projectiles.clear();this.ledger.clear();for(const b of arenaBlocks())this.addProp(b);}
 addProp(b:ArenaBlock,source:string|null=null,group?:string,fragment=false){if(this.props.size>=C.maxBodies)return null;const mat=MATERIALS[b.material],dynamic=!!b.dynamic;let desc=dynamic?RAPIER.RigidBodyDesc.dynamic():RAPIER.RigidBodyDesc.fixed();desc=desc.setTranslation(b.pos.x,b.pos.y,b.pos.z);if(b.rotation)desc.setRotation(b.rotation);if(dynamic)desc.setCcdEnabled(true).setLinearDamping(.15).setAngularDamping(.25);
 const body=this.world.createRigidBody(desc);const mass=b.mass??mat.mass;const collider=this.world.createCollider(RAPIER.ColliderDesc.cuboid(b.size.x/2,b.size.y/2,b.size.z/2).setMass(mass).setFriction(mat.friction).setRestitution(.12),body);
 const p:Prop={id:b.id,body,collider,size:copy(b.size),material:b.material,hp:mat.durability,maxHp:mat.durability,mass,dynamic,support:b.support,group:group||b.id,source,sourceAt:this.time,born:this.time,fragment};this.props.set(p.id,p);this.colliderOwners.set(collider.handle,p.id);return p;}
 removeProp(id:string){const p=this.props.get(id);if(!p)return;this.colliderOwners.delete(p.collider.handle);this.world.removeRigidBody(p.body);this.props.delete(id);}
 ray(origin:Vec,dir:Vec,distance:number,exclude?:string){return this.world.castRayAndGetNormal(new RAPIER.Ray(origin,dir),distance,true,undefined,undefined,undefined,undefined,(c:RAPIER.Collider)=>this.colliderOwners.get(c.handle)!==exclude);}
 lineOfSight(a:Vec,b:Vec,exclude?:string,target?:string){const d=sub(b,a),hit=this.ray(a,norm(d),len(d),exclude);return !hit||this.colliderOwners.get(hit.collider.handle)===target||hit.timeOfImpact>=len(d)-.12;}
 launchProp(prop:Prop,impulse:Vec,source:string|null,point?:Vec){if(!prop.dynamic||!Number.isFinite(prop.mass)||prop.mass<=0)return;prop.source=source;prop.sourceAt=this.time;if(point)prop.body.applyImpulseAtPoint(impulse,point,true);else prop.body.applyImpulse(impulse,true);}
 damageProp(p:Prop,damage:number,impulse:Vec,source:string|null,point:Vec){if(!this.props.has(p.id))return;if(p.material==='foundation')return;this.launchProp(p,impulse,source,point);p.hp-=damage;if(p.hp<=0&&!p.fragment)this.fracture(p,source,p.dynamic?v():impulse);}
 fracture(p:Prop,source:string|null,extraImpulse=v()){if(!this.props.has(p.id))return;
 if(this.props.size+3>C.maxBodies){p.fragment=true;p.dynamic=true;p.hp=0;p.body.setBodyType(RAPIER.RigidBodyType.Dynamic,true);p.body.enableCcd(true);this.launchProp(p,extraImpulse,source);this.checkSupports(source);return;}
 const pos=copy(p.body.translation()),rot={...p.body.rotation()},vel=copy(p.body.linvel()),angular=copy(p.body.angvel()),size=p.size,mass=p.mass,group=this.uid('fracture');this.removeProp(p.id);this.emit('break',pos,{color:MATERIALS[p.material].color,radius:len(size),source,material:p.material});
 // Exactly four gameplay chunks. Their masses sum to the parent's finite mass.
 for(let i=0;i<4;i++){const offset=v((i%2?1:-1)*size.x*.25,(i<2?1:-1)*size.y*.25,0),wp=add(pos,rotate(rot,offset));const chunk=this.addProp({id:this.uid('chunk'),pos:wp,size:v(size.x*.46,size.y*.44,size.z*.88),rotation:rot,material:p.material,dynamic:true,mass:mass/4},source,group,true);if(chunk){chunk.body.setLinvel(add(add(pointVelocity(vel,angular,wp,pos),mul(extraImpulse,1/Math.max(mass,.1))),v((i%2?1:-1)*2.4,0,(i<2?1:-1)*1.4)),true);chunk.body.setAngvel(angular,true);}}
 this.checkSupports(source);
 }
 checkSupports(source:string|null){for(const p of this.props.values())if(p.support&&!p.dynamic&&p.support.every(id=>!this.props.has(id)||this.props.get(id)!.hp<=0)){p.dynamic=true;p.body.setBodyType(RAPIER.RigidBodyType.Dynamic,true);p.body.enableCcd(true);p.body.setLinearDamping(.12);p.source=source;p.sourceAt=this.time;p.group=this.uid('collapse');this.emit('collapse',p.body.translation(),{source,radius:3});}}
 damage(p:Player,amount:number,source:string|null,kind:string,direction=v(),impulse=0){if(this.phase!=='fight'||p.hp<=0||!Number.isFinite(amount))return 0;let scale=p.stats.damageTaken;
 const incoming=norm(mul(direction,-1));const frontal=dot(forward(p.input.yaw),incoming)>.25;
 if(kind!=='debris'&&frontal){if(p.parryTime>0){scale*=.12;impulse*=.25;this.emit('parry',p.body.translation(),{target:p.id});}else if(p.guarding&&p.stamina>0){scale*=.25;p.stamina=Math.max(0,p.stamina-amount*C.shieldImpactCost);p.staminaAt=this.time;impulse*=.35;}}
 if(kind==='debris')scale*=p.stats.debrisTaken;const actual=Math.max(0,amount*scale);p.hp=Math.max(0,p.hp-actual);p.lastDamage=this.time;if(source){p.lastSource=source;p.sourceAt=this.time;}
 if(impulse>0)p.ext=add(p.ext,mul(norm(direction),impulse/C.playerMass*p.stats.knockbackTaken));
 if(actual>.05)this.emit('hit',add(p.body.translation(),v(0,.8,0)),{amount:actual,source,target:p.id,color:kind==='debris'?0xffbe71:kind==='burn'?0xff822f:kind==='poison'?0x9de34d:0xffffff,message:kind});return actual;}
 directHit(p:Player,target:Player|Prop,point:Vec,dir:Vec,damage:number,impulse:number,attackId:string){const w=WEAPONS[p.spec],isPlayer='stats'in target;if(isPlayer&&target.hp>0&&target.blockTime>0&&w.class==='melee'){this.successfulBlock(target,'melee',point,p.id);return;}if(isPlayer){const actual=this.damage(target,damage,p.id,'direct',dir,impulse);if(actual>0){refreshDot(target.burns,p.id,(w.burn||0)+p.stats.burn,this.time,'fire');refreshDot(target.poisons,p.id,p.stats.poison,this.time,'poison');if(w.drain)p.hp=Math.min(p.stats.hp,p.hp+actual*w.drain);p.hits++;if(p.stats.staticEvery&&p.hits%p.stats.staticEvery===0)this.explode(p,point,3,p.stats.staticDamage,60,'static',false);if(w.chain){for(const other of this.props.values())if(other.material!=='foundation'&&len(sub(other.body.translation(),point))<3&&this.lineOfSight(point,other.body.translation(),target.id,other.id)){this.damageProp(other,w.chain,v(),p.id,other.body.translation());this.emit('arc',point,{from:copy(other.body.translation()),color:w.color});break;}}}}
 else this.damageProp(target,damage*p.stats.demolition,dir?mul(dir,impulse):v(),p.id,point);
 if(p.stats.shrapnel&&!this.procAttacks.has(attackId)){this.procAttacks.add(attackId);this.explode(p,point,1.8,p.stats.shrapnel,220*p.stats.impulse,'shrapnel',true);}
 }
 explode(owner:Player,point:Vec,radius:number,damage:number,impulse:number,kind:string,props=true){this.emit(kind==='static'?'arc':kind==='blockPulse'?'blockPulse':'explosion',point,{radius,color:kind==='blockPulse'?0x91f7eb:WEAPONS[owner.spec].color,source:owner.id,spec:owner.spec});for(const p of this.players.values()){if(p.id===owner.id||p.hp<=0)continue;const d=sub(p.body.translation(),point),dist=len(d);if(dist<radius+.4&&this.lineOfSight(add(point,mul(norm(d),.1)),p.body.translation(),kind==='blockPulse'?owner.id:undefined,p.id)){const fall=1-clamp(dist/(radius+.4),0,.85);this.damage(p,damage*fall,owner.id,kind,norm(d),impulse*fall);}}
 if(props)for(const p of [...this.props.values()]){if(p.material==='foundation')continue;const d=sub(p.body.translation(),point),dist=len(d);if(dist<radius+len(p.size)*.35&&(kind!=='blockPulse'||this.lineOfSight(point,p.body.translation(),owner.id,p.id))){const fall=1-clamp(dist/(radius+len(p.size)*.35),0,.85);this.damageProp(p,damage*fall*owner.stats.demolition,mul(norm(add(d,v(0,.3,0))),impulse*fall),owner.id,point);}}
 }
 spawnProjectile(owner:Player,multiplier=1,secondary=false){if(this.projectiles.size>=C.maxProjectiles)return;const w=WEAPONS[owner.spec],aim=forward(owner.input.yaw,owner.input.pitch),trace=(origin:Vec,direction:Vec,distance:number)=>this.ray(origin,direction,distance,owner.id)?.timeOfImpact??null;
 const camera=cameraPosition(owner.body.translation(),owner.input.yaw,owner.input.pitch,owner.input.camera||'third',trace);
 const targetHit=this.ray(camera,aim,w.range+5,owner.id),target=add(camera,mul(aim,targetHit?targetHit.timeOfImpact:w.range+5));
 const start=weaponMuzzle(owner.body.translation(),owner.input.yaw,trace);
 const count=secondary?1:1+owner.stats.extraProjectiles,volleyId=this.uid('volley');
 for(let n=0;n<count&&this.projectiles.size<C.maxProjectiles;n++){
 const fan=count>1?(n/(count-1)-.5)*C.volleyFanDegrees*Math.PI/180:0;
 const center=norm(sub(target,start)),yaw=Math.atan2(center.x,center.z)+fan,pitch=Math.atan2(center.y,Math.hypot(center.x,center.z));
 const dir=norm(add(forward(yaw,pitch),v((this.random()-.5)*w.spread,(this.random()-.5)*w.spread,(this.random()-.5)*w.spread)));
 const speed=w.speed*owner.stats.projectileSpeed*(secondary&&w.secondary==='fireball'?.78:1),id=this.uid('shot');
 this.projectiles.set(id,{reflections:0,burnDps:(w.burn||0)+owner.stats.burn,poisonDps:owner.stats.poison,demolition:owner.stats.demolition,elements:attackElements((w.burn||0)+owner.stats.burn,owner.stats.poison),id,pos:copy(start),vel:mul(dir,speed),owner:owner.id,spec:owner.spec,damage:w.damage*owner.stats.damage*multiplier*(count>1?C.volleyDamage:1),impulse:w.impulse*owner.stats.impulse*(secondary?1.5:1),life:C.projectileLifetime,distanceLeft:C.projectileMaxTravel,gravity:w.gravity,radius:secondary&&w.secondary==='fireball'?.28:w.class==='magic'?.14:.045,direct:true,attackId:volleyId,bounces:owner.stats.bounces,pierces:owner.stats.pierces,homing:owner.stats.homing,hit:new Set(),effectsUsed:false});
 }
 this.emit('shot',start,{source:owner.id,spec:owner.spec,color:w.color});
 }
 beginBlock(p:Player){if(this.phase!=='fight'||p.hp<=0||p.blockCd>0||p.blockTime>0)return false;
 p.blockTime=blockDuration(p.stats);p.blockCd=blockCooldown(p.stats);p.lastBlock=this.time;p.blockProcUsed=false;p.swing=null;p.burst=0;p.guarding=false;p.parryTime=0;
 this.emit('blockStart',p.body.translation(),{source:p.id,color:0x91f7eb,radius:1.15});return true;
 }
 successfulBlock(p:Player,kind:string,point:Vec,source:string){this.emit('blockHit',point,{source:p.id,target:source,message:kind,color:0x91f7eb});
 if(p.stats.blockPulseDamage>0&&!p.blockProcUsed){p.blockProcUsed=true;this.explode(p,p.body.translation(),C.blockPulseRadius,p.stats.blockPulseDamage,p.stats.blockPulseImpulse,'blockPulse',true);}
 }
 reflectProjectile(shot:Projectile,target:Player,point:Vec){this.successfulBlock(target,'projectile',point,shot.owner);
 if((shot.reflections||0)>=C.maxReflections){this.projectiles.delete(shot.id);this.emit('blockAbsorb',point,{source:target.id,color:0x91f7eb});return;}
 // Reverse the pre-impact flight vector. Do not replenish lifetime/travel or restart direct-hit effects.
 const speed=Math.min(C.maxReflectedSpeed,len(shot.vel)*target.stats.reflectSpeed);shot.vel=mul(norm(shot.vel),-speed);shot.owner=target.id;shot.reflections=(shot.reflections||0)+1;shot.damage=Math.min(C.maxReflectedDamage,shot.damage*target.stats.reflectDamage);shot.direct=false;shot.homing=0;shot.hit.clear();shot.attackId=this.uid('reflection');shot.pos=add(point,mul(norm(shot.vel),.025));
 this.emit('reflect',point,{source:target.id,spec:shot.spec,color:0x91f7eb,amount:shot.damage});
 }
 preparePlayer(p:Player,dt:number){const queued=this.inputQueues.get(p.id)?.queue.shift();if(queued){p.input=queued;p.inputAt=this.time;}else if(this.inputQueues.has(p.id)){p.input={...p.input,jump:false,dash:false,block:false,reload:false,secondary:false};}if(p.bot)p.input=this.botInput(p);else if(this.time-p.inputAt>(this.options.inputHoldSeconds??C.staleInputSeconds))p.input={...idleInput(),seq:p.input.seq,yaw:p.input.yaw,pitch:p.input.pitch};p.ack=p.input.seq;
 p.blockTime=Math.max(0,p.blockTime-dt);p.blockCd=Math.max(0,p.blockCd-dt);
 if(p.input.block&&!p.blockHeld)this.beginBlock(p);p.blockHeld=p.input.block===true;
 }
 spendResource(p:Player,cost:number){if(WEAPONS[p.spec].class==='magic'){if(p.mana<cost)return false;p.mana-=cost;}else if(WEAPONS[p.spec].class==='melee'){if(p.stamina<cost)return false;p.stamina-=cost;if(cost>0)p.staminaAt=this.time;}return true;}
 beginReload(p:Player){const w=WEAPONS[p.spec];if(w.ammo&&p.ammo<magazineCapacity(p.spec,p.stats)&&!p.reloadTime&&p.burst===0){p.reloadTime=w.reload;this.emit('reloadStart',p.body.translation(),{source:p.id,spec:p.spec});}}
 primary(p:Player){const w=WEAPONS[p.spec];if(p.blockTime>0||p.cooldown>0||p.reloadTime>0||p.burst>0||p.swing||p.hp<=0)return;if(w.ammo&&p.ammo<=0){this.beginReload(p);return;}
 const cost=w.cost+(w.class==='melee'?p.stats.extraStrikes*C.followupCost:0);if(!this.spendResource(p,cost))return;if(w.ammo)p.ammo--;
 p.cooldown=w.interval/p.stats.attackRate;p.lastAttack=this.time;if(w.class==='melee'){
 p.swing={at:this.time+w.windup/p.stats.attackRate,until:this.time+(w.windup+.16)/p.stats.attackRate,id:this.uid('swing'),hit:new Set(),yaw:p.input.yaw,remaining:p.stats.extraStrikes,damageScale:1};
 p.cooldown=Math.max(p.cooldown,(w.windup+.16+p.stats.extraStrikes*(C.followupGap+.16)+.12)/p.stats.attackRate);
 p.ext=add(p.ext,mul(forward(p.input.yaw),w.id==='sword'?2.4:1));this.emit('windup',p.body.translation(),{source:p.id,spec:p.spec,radius:w.range*p.stats.reach});}else this.spawnProjectile(p);
 }
 secondary(p:Player){const w=WEAPONS[p.spec];if(p.blockTime>0||p.secondaryCd>0||p.reloadTime>0||p.cooldown>0||p.burst>0||p.swing||p.hp<=0)return;const action=w.secondary;
 const cost=w.class==='magic'?(action==='fireball'?25:action==='push'?22:action==='nova'?24:20):(w.secondaryCost||0),burstCount=w.burstCount||3;
 if(action==='power'&&p.ammo<2)return;if(action==='burst'&&p.ammo<burstCount)return;if(!this.spendResource(p,cost))return;p.secondaryCd=w.secondaryCooldown;p.lastSecondary=this.time;p.lastAttack=this.time;
 if(action==='power'){p.ammo-=2;p.cooldown=.55/p.stats.attackRate;this.spawnProjectile(p,2,true);}else if(action==='burst'){p.ammo-=burstCount;p.burst=burstCount;p.burstAt=this.time;p.cooldown=(.08*burstCount+.15)/p.stats.attackRate;}
 else if(action==='fireball'){p.cooldown=.6/p.stats.attackRate;this.spawnProjectile(p,1.55,true);}else if(action==='parry'){p.parryTime=.4;p.ext=add(p.ext,mul(forward(p.input.yaw),3));}
 else if(action==='sidestep'){p.ext=add(p.ext,mul(forward(p.input.yaw+Math.PI/2),14));}
 else if(action==='charge'){p.ext=add(p.ext,mul(forward(p.input.yaw),11));p.parryTime=.28;}
 else if(['push','pull','nova'].includes(action)){const pos=p.body.translation(),f=forward(p.input.yaw),radius=action==='nova'?4.2:5;this.emit(action,pos,{radius,color:w.color,source:p.id,spec:p.spec});for(const other of this.players.values()){if(other===p)continue;const d=sub(other.body.translation(),pos);if(len(d)<radius&&(action==='nova'||dot(norm(d),f)>.35)&&this.lineOfSight(add(pos,v(0,.3,0)),other.body.translation(),p.id,other.id))this.damage(other,action==='nova'?20:8,p.id,'secondary',action==='pull'?mul(norm(d),-1):norm(d),(action==='push'?620:440)*p.stats.impulse);}for(const prop of [...this.props.values()]){if(prop.material==='foundation')continue;const d=sub(prop.body.translation(),pos);if(len(d)<radius&&(action==='nova'||dot(norm(d),f)>.2)&&this.lineOfSight(add(pos,v(0,.4,0)),prop.body.translation(),p.id,prop.id))this.damageProp(prop,action==='nova'?20:5,mul(action==='pull'?mul(norm(d),-1):norm(add(d,v(0,.4,0))),500*p.stats.impulse),p.id,prop.body.translation());}}
 }
 melee(p:Player){const swing=p.swing;if(!swing)return;if(this.time>swing.until){if(swing.remaining>0){p.swing={...swing,at:this.time+C.followupGap/p.stats.attackRate,until:this.time+(C.followupGap+.16)/p.stats.attackRate,remaining:swing.remaining-1,damageScale:C.followupDamage,hit:new Set(),yaw:p.input.yaw};p.lastAttack=this.time;this.emit('windup',p.body.translation(),{source:p.id,spec:p.spec,radius:WEAPONS[p.spec].range*p.stats.reach});}else p.swing=null;return;}if(this.time<swing.at)return;const w=WEAPONS[p.spec],origin=add(p.body.translation(),v(0,.15,0)),range=w.range*p.stats.reach;const progress=clamp((this.time-swing.at)/(swing.until-swing.at),0,1),angle=swing.yaw+(progress-.5)*w.arc;
 // A moving capsule-like segment plus the previous substep angular margin covers the full attack arc.
 const dir=forward(angle);for(const target of [...this.players.values(),...this.props.values()]){if(target.id===p.id||swing.hit.has(target.id)||('material'in target&&!this.props.has(target.id)))continue;const d=sub(target.body.translation(),origin),dist=len(d),extra='stats'in target?.45:Math.min(.8,len(target.size)*.3);if(Math.abs(d.y)>1.6+extra||dist>range+extra||dot(norm(v(d.x,0,d.z)),dir)<Math.cos(.24+Math.asin(Math.min(.95,extra/Math.max(.1,dist)))))continue;if(!this.lineOfSight(origin,target.body.translation(),p.id,target.id))continue;swing.hit.add(target.id);this.directHit(p,target,target.body.translation(),norm(add(d,v(0,.15,0))),w.damage*p.stats.damage*swing.damageScale,w.impulse*p.stats.impulse*swing.damageScale,swing.id);this.emit('slash',origin,{source:p.id,radius:range,color:w.color});}
 }
 stepProjectiles(dt:number){for(const shot of [...this.projectiles.values()]){const h=Math.min(dt,shot.life);if(h<=0){this.projectiles.delete(shot.id);continue;}shot.life-=h;if(shot.direct&&shot.homing>0){const dir=norm(shot.vel);for(const target of this.players.values()){if(target.id===shot.owner||target.hp<=0||shot.hit.has(target.id))continue;const delta=sub(add(target.body.translation(),v(0,.15,0)),shot.pos);if(len(delta)<=C.homingRange&&dot(dir,norm(delta))>=Math.cos(C.homingConeDegrees*Math.PI/180)&&this.lineOfSight(shot.pos,target.body.translation(),shot.owner,target.id)){shot.vel=steerVelocity(shot.vel,delta,shot.homing*Math.PI/180*h);break;}}}
 const before=copy(shot.vel),flight=ballisticStep(before,shot.gravity,h),distance=Math.min(len(flight.displacement),shot.distanceLeft),displacement=mul(norm(flight.displacement),distance);shot.vel=flight.velocity;shot.distanceLeft-=distance;if(distance<=0){this.projectiles.delete(shot.id);continue;}const hit=this.world.castShape(shot.pos,{x:0,y:0,z:0,w:1},norm(displacement),new RAPIER.Ball(shot.radius),0,distance,true,undefined,undefined,undefined,undefined,(c:RAPIER.Collider)=>{const id=this.colliderOwners.get(c.handle);return id!==shot.owner&&!shot.hit.has(id||'');});if(!hit){shot.pos=add(shot.pos,displacement);continue;}
 shot.vel=add(before,v(0,-shot.gravity*h*clamp(hit.time_of_impact/Math.max(.00001,len(flight.displacement)),0,1),0));
 const id=this.colliderOwners.get(hit.collider.handle)||'',point=add(shot.pos,mul(norm(displacement),hit.time_of_impact)),owner=this.players.get(shot.owner),target=this.players.get(id)||this.props.get(id);if(!owner||!target){this.projectiles.delete(shot.id);continue;}const dir=norm(shot.vel);if('stats'in target&&target.hp>0&&target.blockTime>0){this.reflectProjectile(shot,target,point);continue;}
 if(shot.direct)this.directHit(owner,target,point,dir,shot.damage,shot.impulse,shot.attackId);else if('stats'in target){const actual=this.damage(target,shot.damage,shot.owner,shot.reflections?'reflected':'secondary',dir,shot.impulse);if(actual>0&&shot.reflections){refreshDot(target.burns,shot.owner,shot.burnDps||0,this.time,'fire');refreshDot(target.poisons,shot.owner,shot.poisonDps||0,this.time,'poison');}}else this.damageProp(target,shot.damage*(shot.demolition??owner.stats.demolition),mul(dir,shot.impulse),owner.id,point);
 this.emit('impact',point,{from:copy(shot.pos),color:WEAPONS[shot.spec].color,source:owner.id,spec:shot.spec,material:'material'in target?target.material:undefined});
 if((shot.direct||shot.reflections)&&!shot.effectsUsed){shot.effectsUsed=true;const w=WEAPONS[shot.spec];if(w.blast)this.explode(owner,point,shot.radius>.2?3:w.blast,shot.damage*.38,shot.impulse,'blast',true);
 if(shot.direct&&owner.stats.split>0){const count=2+owner.stats.split;for(let j=0;j<count&&this.projectiles.size<C.maxProjectiles;j++){const a=(j-(count-1)/2)*.32,side=forward(owner.input.yaw+a,owner.input.pitch);const sid=this.uid('split');this.projectiles.set(sid,{...shot,id:sid,pos:add(point,mul(norm(mul(dir,-1)),.18)),vel:mul(side,len(shot.vel)*.75),damage:shot.damage*.22,impulse:shot.impulse*.2,direct:false,reflections:0,burnDps:0,poisonDps:0,elements:[],life:C.splitLifetime,distanceLeft:C.splitMaxTravel,homing:0,bounces:0,pierces:0,hit:new Set('stats'in target?[id]:[]),effectsUsed:true});}}}
 if('stats'in target&&shot.pierces>0){shot.pierces--;shot.hit.add(id);shot.pos=add(point,mul(dir,.08));}
 else if(!('stats'in target)&&shot.bounces>0&&this.props.has(id)){const normal=rotate(target.body.rotation(),hit.normal2);shot.vel=sub(shot.vel,mul(normal,2*dot(shot.vel,normal)));shot.pos=add(point,mul(norm(shot.vel),shot.radius+.06));shot.damage*=.7;shot.bounces--;}
 else this.projectiles.delete(shot.id);
 }}
 botInput(p:Player):Input{const opponent=[...this.players.values()].find(x=>x!==p)!,i=idleInput();i.seq=p.input.seq+1;if(p.bot==='dummy')return {...i,yaw:Math.PI};const pos=p.body.translation(),target=opponent.body.translation(),delta=sub(target,pos),dist=len(delta),w=WEAPONS[p.spec],difficulty=p.bot==='hard'?2:p.bot==='normal'?1:0;
 let react=false;if(this.time>=p.botThink){react=true;p.botThink=this.time+[.32,.18,.1][difficulty];p.botAim=add(target,v((this.random()-.5)*[1.8,.8,.4][difficulty],.15+(this.random()-.5)*.2,(this.random()-.5)*.6));}
 const aim=sub(p.botAim,add(pos,v(0,.5,0)));i.yaw=Math.atan2(aim.x,aim.z);i.pitch=Math.atan2(aim.y,Math.hypot(aim.x,aim.z));if(w.class!=='melee'){const arc=ballisticPitch(Math.hypot(aim.x,aim.z),aim.y,w.speed*p.stats.projectileSpeed,w.gravity);i.pitch=clamp(i.pitch+(arc-i.pitch)*[.65,.85,.95][difficulty],-1.1,1.1);}const los=this.lineOfSight(add(pos,v(0,.5,0)),add(target,v(0,.4,0)),p.id,opponent.id);const desired=w.class==='melee'?w.range*.65:w.class==='magic'?8:10;let move=norm(v(delta.x,0,delta.z));if(dist<desired-1)move=mul(move,-.8);else if(dist<desired+1)move=v();if(difficulty>0&&w.class!=='melee'&&los)move=add(move,mul(forward(i.yaw+Math.PI/2),Math.sin(this.time*1.1+p.id.length)>.0?.65:-.65));
 if(difficulty>0&&w.class!=='melee'&&(p.reloadTime>0||(w.ammo>0&&p.ammo<=1)||p.mana<18)){const covers=[...this.props.values()].filter(c=>!c.dynamic&&c.material!=='foundation'&&c.size.y>1).sort((a,b)=>len(sub(a.body.translation(),pos))-len(sub(b.body.translation(),pos)));if(covers[0]){const c=covers[0],away=norm(sub(c.body.translation(),target)),safe=add(c.body.translation(),mul(away,Math.max(c.size.x,c.size.z)*.6+1));move=norm(v(safe.x-pos.x,0,safe.z-pos.z));if(len(sub(safe,pos))<1)move=v();}}
 const front=this.ray(add(pos,v(0,-.4,0)),norm(move),1.1,p.id);if(front&&front.timeOfImpact<1){move=add(mul(move,.25),mul(forward(i.yaw+Math.PI/2),Math.sin(this.time*.4)>0?1:-1));i.jump=true;}
 if(w.class==='melee'&&p.stamina<w.cost)move=mul(norm(v(delta.x,0,delta.z)),-.8);
 if(Math.abs(pos.x)>11)move.x=-Math.sign(pos.x);if(Math.abs(pos.z)>10)move.z=-Math.sign(pos.z);
 i.x=clamp(move.x,-1,1);i.z=clamp(move.z,-1,1);i.attack=w.class==='melee'?dist<w.range*1.25:los||!!front;i.reload=!!w.ammo&&p.ammo<2;i.secondary=difficulty>0&&((w.class==='melee'&&dist<5)||(w.class==='magic'&&dist<7)||w.class==='ranged');i.dash=difficulty>0&&w.class==='melee'&&dist>4&&dist<11&&Math.abs(pos.x)<10&&Math.abs(pos.z)<9;
 if(react&&p.blockCd<=0&&!p.blockHeld){const threat=[...this.projectiles.values()].some(shot=>{if(shot.owner===p.id)return false;const d=sub(pos,shot.pos),speed=len(shot.vel),eta=dot(d,norm(shot.vel))/Math.max(1,speed),miss=len(sub(d,mul(shot.vel,eta)));return eta>0&&eta<[.38,.30,.24][difficulty]&&miss<.9&&this.lineOfSight(shot.pos,pos,shot.owner,p.id);})||!!(opponent.swing&&dist<WEAPONS[opponent.spec].range+1&&opponent.swing.at-this.time<.24&&los);
 i.block=threat&&this.random()<[.35,.65,.85][difficulty];if(i.block){i.attack=false;i.secondary=false;}}
 if(len(sub(pos,p.previousPos))<.005&&len(move)>.2)p.botBlocked+=1/C.simulationHz;else p.botBlocked=0;if(p.botBlocked>.65){i.jump=true;i.x=Math.sin(this.time*3);i.z=Math.cos(this.time*3);}p.previousPos=copy(pos);return i;}
 updatePlayer(p:Player,dt:number){const w=WEAPONS[p.spec];for(const key of ['cooldown','secondaryCd','parryTime'] as const)p[key]=Math.max(0,p[key]-dt);
 if(p.reloadTime>0){p.reloadTime=Math.max(0,p.reloadTime-dt);if(p.reloadTime===0){p.ammo=magazineCapacity(p.spec,p.stats);this.emit('reloadEnd',p.body.translation(),{source:p.id,spec:p.spec});}}
 p.mana=Math.min(p.stats.maxMana,p.mana+dt*C.manaRegen);
 p.guarding=p.blockTime<=0&&w.secondary==='guard'&&p.input.secondary&&p.stamina>2&&p.cooldown<=0;if(p.guarding){p.stamina=Math.max(0,p.stamina-dt*C.shieldDrain);p.staminaAt=this.time;}else if(this.time-p.staminaAt>=C.staminaRegenDelay)p.stamina=Math.min(p.stats.maxStamina,p.stamina+dt*C.staminaRegen);if(p.hp<=0){p.body.setLinvel(v(),true);return;}
 advanceDots(p.burns,this.time,'fire',(source,amount)=>this.damage(p,amount,source,'burn'));advanceDots(p.poisons,this.time,'poison',(source,amount)=>this.damage(p,amount,source,'poison'));
 const pos=p.body.translation();
 if(p.input.reload)this.beginReload(p);
 if(p.input.secondary&&w.secondary!=='guard')this.secondary(p);if(p.input.attack&&!p.guarding)this.primary(p);
 if(p.burst>0&&this.time>=p.burstAt){p.burst--;p.burstAt=this.time+.08/p.stats.attackRate;this.spawnProjectile(p,.9);}
 this.melee(p);
 const motion=prepareMotion(this.world,p.body,p.collider,p,p.input,p.stats,dt,p.guarding,!!p.swing);
 if(motion.dashed)this.emit('dash',pos,{source:p.id,color:0x91f7df});if(motion.jumped)this.emit('jump',pos,{source:p.id});
 if(pos.y<-6)this.damage(p,100000,null,'fall');
 }
 physics(dt:number){type Pre={pos:Vec;vel:Vec;ang:Vec;rot:{x:number;y:number;z:number;w:number}};const pre=new Map<string,Pre>();for(const p of [...this.players.values(),...this.props.values()])pre.set(p.id,{pos:copy(p.body.translation()),vel:copy(p.body.linvel()),ang:copy(p.body.angvel()),rot:{...p.body.rotation()}});
 this.ledger.beginTick();this.world.step();
 for(const prop of this.props.values()){if(!prop.dynamic||prop.mass<=0)continue;const a=pre.get(prop.id)!;
 for(const p of this.players.values()){const b=pre.get(p.id)!;let contact:{point:Vec;normal:Vec}|null=null;this.world.contactPair(prop.collider,p.collider,(m:RAPIER.TempContactManifold,flipped:boolean)=>{if(m.numSolverContacts()>0){const normal=m.normal();contact={point:copy(m.solverContactPoint(0)),normal:mul(normal,flipped?-1:1)};}});
 // Supplemental relative shape sweep catches fast moving chunks even if CCD resolves contact before a persistent manifold is made.
 if(!contact&&len(sub(a.vel,b.vel))*dt>.12){const hit=prop.collider.shape.castShape(a.pos,a.rot,a.vel,p.collider.shape,b.pos,b.rot,b.vel,0,dt,true);if(hit&&hit.time_of_impact*len(a.vel)<=len(sub(prop.body.translation(),a.pos))+.15){contact={point:add(add(a.pos,mul(a.vel,hit.time_of_impact)),rotate(a.rot,hit.witness1)),normal:rotate(a.rot,hit.normal1)};}}
 if(contact){const c=contact as {point:Vec;normal:Vec};const av=pointVelocity(a.vel,a.ang,c.point,a.pos),bv=pointVelocity(b.vel,b.ang,c.point,b.pos);const speed=closingSpeed(av,bv,c.normal);const calc=impactDamage(prop.mass,speed);if(len(av)<C.minimumImpactSpeed)calc.damage=0;const bounded=this.ledger.claim(`${prop.id}:${p.id}`,`${prop.group}:${p.id}`,this.time,calc.damage);const source=this.time-prop.sourceAt<C.attributionSeconds?prop.source:null;
 if(bounded>0){const actual=this.damage(p,bounded,source,'debris');this.impact={mass:prop.mass,speed,energy:calc.energy,damage:actual,source:source||'Environment',object:prop.id,time:this.time};this.emit('debrisHit',c.point,{source,target:p.id,amount:actual});}
 }
 }
 // A launched object transfers recent responsibility to another object on collision.
 if(prop.source&&this.time-prop.sourceAt<C.attributionSeconds&&len(a.vel)>C.minimumImpactSpeed){for(const other of this.props.values())if(other!==prop&&other.dynamic&&!other.source){this.world.contactPair(prop.collider,other.collider,(m:RAPIER.TempContactManifold)=>{if(m.numSolverContacts()){other.source=prop.source;other.sourceAt=this.time;}});}}
 }
 // Preserve collision response in external velocity; do not reapply the collision impulse as damage knockback.
 for(const p of this.players.values()){const before=pre.get(p.id)!,after=p.body.linvel();finishMotion(p,before.vel,after,p.stats.knockbackTaken,dt);}
 this.ledger.endTick(this.time);
 for(const prop of [...this.props.values()])if(prop.dynamic&&prop.body.translation().y<-15)this.removeProp(prop.id);
 }
 beginNextSet(){this.setNumber++;this.round=1;for(const p of this.players.values()){p.roundWins=0;p.offers=[];}this.resetRound();this.countdown();}
 resolveRound(){
 if(this.phase!=='fight')return;
 const alive=[...this.players.values()].filter(p=>p.hp>0);if(alive.length===2)return;
 this.winner=alive.length===1?alive[0].id:null;this.setWinner=null;
 if(this.winner){const winner=alive[0],loser=[...this.players.values()].find(p=>p.id!==this.winner)!;winner.roundWins++;
 const source=loser.lastSource&&this.time-loser.sourceAt<C.attributionSeconds?this.players.get(loser.lastSource)?.name:null;
 if(winner.roundWins>=this.options.roundsPerSet!){winner.score++;this.setWinner=winner.id;this.result=`${winner.name} wins set ${this.setNumber} · ${winner.roundWins}–${loser.roundWins}`;}
 else this.result=`${winner.name} wins the round · ${winner.roundWins}–${loser.roundWins} in this set${source?` · ${source}`:' · arena knockout'}`;
 }else this.result='Simultaneous knockout · replay this round; set progress stays';
 if(this.setWinner&&this.players.get(this.setWinner)!.score>=this.options.wins!){this.phase='match';this.phaseEnd=0;this.result=`${this.players.get(this.setWinner)!.name} wins the match · ${this.options.wins} sets`;}
 else{this.phase='result';this.phaseEnd=this.time+this.options.resultSeconds!;}
 }
 advance(){if(this.phase==='specialization'){for(const p of this.players.values())if(!p.selected&&(p.bot||this.time>=this.phaseEnd))this.selectSpec(p.id,p.spec);}
 else if(this.phase==='draft'){for(const p of this.players.values())if(!p.selected&&(p.bot||this.time>=this.phaseEnd))this.selectChip(p.id,p.offers[0]);}
 else if(this.phase==='countdown'&&this.time>=this.phaseEnd){this.phase='fight';this.fightStart=this.time;}
 else if(this.phase==='result'&&this.time>=this.phaseEnd){
  if(!this.setWinner){if(this.winner)this.round++;this.resetRound();this.countdown();return;}
  this.phase='draft';this.phaseEnd=this.time+this.options.selectionSeconds!;
  for(const p of this.players.values()){p.selected=!this.options.bothDraft&&p.id===this.setWinner;p.offers=p.selected?[]:offerChips(p.spec,p.chips,()=>this.random());if(!p.selected&&!p.offers.length)p.selected=true;}
  if([...this.players.values()].every(p=>p.selected))this.beginNextSet();
 }
 }
 step(dt=1/C.simulationHz){const started=performance.now();this.time+=dt;this.tick++;for(const p of this.players.values())if(!p.connected&&p.disconnectedAt!==null&&this.time-p.disconnectedAt>=C.disconnectSeconds&&this.phase!=='match'){const winner=[...this.players.values()].find(x=>x!==p&&x.connected);this.winner=winner?.id||null;this.result=winner?`${winner.name} wins · opponent disconnected`:'Room closed · players disconnected';this.phase='match';}
 this.advance();if(this.phase==='fight'){for(const p of this.players.values())this.preparePlayer(p,dt);for(const p of this.players.values())this.updatePlayer(p,dt);this.stepProjectiles(dt);this.physics(dt);
 if(this.time-this.fightStart>C.maxRoundSeconds&&!this.options.sandbox){for(const p of this.players.values())this.damage(p,dt*18,null,'overtime');}
 this.resolveRound();}else if(this.phase==='lobby'||this.phase==='countdown')this.world.step();this.tickMs=performance.now()-started;}
 debug(command:any,playerId:string){if(!this.options.sandbox)return false;const p=this.players.get(playerId);if(!p||!command||typeof command.action!=='string')return false;
 if(command.action==='reset'){this.resetRound();this.phase='fight';this.fightStart=this.time;}
 else if(command.action==='heal'){for(const q of this.players.values()){q.hp=q.stats.hp;q.mana=q.stats.maxMana;q.stamina=q.stats.maxStamina;q.staminaAt=-10;q.swing=null;q.burst=0;q.guarding=false;q.parryTime=0;q.blockTime=q.blockCd=0;q.blockHeld=q.blockProcUsed=false;q.lastBlock=-10;q.cooldown=q.secondaryCd=q.dashCd=q.reloadTime=0;q.ammo=magazineCapacity(q.spec,q.stats);q.burns.clear();q.poisons.clear();}if(this.phase!=='fight')this.phase='fight';}
 else if(command.action==='arena')this.resetArena();
 else if(command.action==='chip'){const c=CHIPS.find(x=>x.id===command.id);if(!c)return false;const delta=command.remove?-1:1;p.chips[c.id]=clamp((p.chips[c.id]||0)+delta,0,c.max);p.stats=statsFor(p.chips);p.hp=p.stats.hp;p.mana=p.stats.maxMana;p.stamina=p.stats.maxStamina;p.ammo=magazineCapacity(p.spec,p.stats);}
 else if(command.action==='spec'){if(!Object.hasOwn(WEAPONS,command.id))return false;p.spec=command.id;p.class=WEAPONS[p.spec].class;p.ammo=magazineCapacity(p.spec,p.stats);p.mana=p.stats.maxMana;p.stamina=p.stats.maxStamina;p.swing=null;p.burst=0;p.cooldown=p.reloadTime=p.secondaryCd=0;p.guarding=false;p.blockTime=p.blockCd=0;p.blockHeld=p.blockProcUsed=false;p.lastBlock=-10;}
 else if(command.action==='bot'){const bot=[...this.players.values()].find(q=>q!==p);if(bot&&['dummy','easy','normal','hard'].includes(command.difficulty))bot.bot=command.difficulty;}
 else if(command.action==='launch'){const mass=clamp(Number(command.mass)||8,1,150),speed=clamp(Number(command.speed)||10,0,100);const material:Material=['wood','stone','metal'].includes(command.material)?command.material:'wood';const target=[...this.players.values()].find(q=>q!==p)!;let pos:Vec,velocity:Vec;if(command.mode==='fall'){pos=add(target.body.translation(),v(0,6,0));velocity=v();}else if(command.mode==='settled'){pos=add(target.body.translation(),v(1.5,-.3,0));velocity=v();}else{const dir=norm(sub(target.body.translation(),p.body.translation()));pos=add(target.body.translation(),add(mul(dir,-5),v(command.mode==='glance'?.8:0,.1,0)));velocity=mul(dir,speed);}const prop=this.addProp({id:this.uid('launcher'),pos,size:v(.8,.8,.8),material,dynamic:true,mass},p.id);if(prop){prop.body.setLinvel(velocity,true);if(command.spin)prop.body.setAngvel(v(0,0,12),true);}}
 else return false;return true;
 }
 snapshot():Snapshot{return {generation:this.generation,time:this.time,tick:this.tick,phase:this.phase,remaining:Math.max(0,this.phaseEnd-this.time),round:this.round,setNumber:this.setNumber,setWinner:this.setWinner,winner:this.winner,result:this.result,options:this.options,players:[...this.players.values()].map(p=>({statuses:([['fire',p.burns],['poison',p.poisons]] as const).flatMap(([element,dots])=>dots.size?[{element,dps:[...dots.values()].reduce((sum,d)=>sum+d.dps,0),remaining:Math.max(...[...dots.values()].map(d=>Math.max(0,d.until-this.time)))}]:[]),id:p.id,name:p.name,color:p.color,class:p.class,spec:p.spec,pos:copy(p.body.translation()),vel:copy(p.body.linvel()),move:copy(p.move),external:copy(p.ext),dashTime:p.dashTime,swinging:!!p.swing,yaw:p.input.yaw,pitch:p.input.pitch,hp:p.hp,maxHp:p.stats.hp,mana:p.mana,maxMana:p.stats.maxMana,ammo:p.ammo,maxAmmo:magazineCapacity(p.spec,p.stats),stamina:p.stamina,maxStamina:p.stats.maxStamina,blockTime:p.blockTime,blockCd:p.blockCd,blockCooldown:blockCooldown(p.stats),blockDuration:blockDuration(p.stats),lastBlock:p.lastBlock,guarding:p.guarding||p.parryTime>0,dashCd:p.dashCd,secondaryCd:p.secondaryCd,cooldown:p.cooldown,reloadTime:p.reloadTime,score:p.score,roundWins:p.roundWins,chips:{...p.chips},ready:p.ready,selected:p.selected,offers:[...p.offers],connected:p.connected,bot:p.bot,ack:p.ack,grounded:p.grounded,lastAttack:p.lastAttack,lastSecondary:p.lastSecondary,reach:WEAPONS[p.spec].range*p.stats.reach,windup:WEAPONS[p.spec].windup})),props:[...this.props.values()].map(p=>({id:p.id,pos:copy(p.body.translation()),rot:{...p.body.rotation()},size:p.size,material:p.material,hp:Number.isFinite(p.hp)?p.hp:-1,maxHp:Number.isFinite(p.maxHp)?p.maxHp:-1,mass:p.mass,dynamic:p.dynamic,support:p.support,fragment:p.fragment,vel:copy(p.body.linvel())})),projectiles:[...this.projectiles.values()].map(p=>({owner:p.owner,reflections:p.reflections||0,id:p.id,pos:copy(p.pos),vel:copy(p.vel),spec:p.spec,radius:p.radius,elements:p.elements||[]})),events:[...this.events],impact:this.impact,metrics:{bodies:this.props.size+this.players.size,projectiles:this.projectiles.size,tickMs:this.tickMs}};}
 dispose(){this.world.free();}
}
